# LIKENet - demo multipagina per il team IT

Questa versione e' una demo funzionale dell'esperienza proposta. Non crea un account reale e non invia informazioni a un server. Per rendere visibile il flusso al team IT, salva profilo ed eventi dimostrativi soltanto nel browser dell'utente (`localStorage`).

## Pagine pubbliche

- `/passioni/volley`
- `/passioni/basket`
- `/passioni/beach`
- `/passioni/music`
- `/passioni/night`
- `/passioni/entertainment`

## Percorso iscritti simulato

- `/`: selezione interessi e creazione guidata del profilo demo
- `/iscriviti`: accesso dimostrativo con Google o Facebook
- `/me`: homepage personale, riepilogo e cancellazione dei dati demo
- `/me/preferiti`: contenuti salvati
- `/me/percorsi`: percorsi editoriali

## Dati dimostrativi

Profilo salvato con la chiave `likenet-demo-profile`:

- nome ed email;
- citta' facoltativa e fascia d'eta';
- passioni selezionate;
- versione e data del consenso, con preferenza marketing separata;
- data di creazione.

Eventi salvati con la chiave `likenet-demo-events` (massimo 50):

- `page_view`;
- `interest_selected`;
- `onboarding_started`;
- `demo_profile_completed`.

La pagina `/me` permette di cancellare profilo, eventi e identificativo della sessione demo.

## Avvio locale

Richiede Node.js 22 o successivo e pnpm.

```bash
pnpm install
pnpm dev
```

## Indicazioni per la realizzazione

La versione di produzione dovra' collegare i pulsanti social a un servizio di autenticazione reale, proteggere le pagine `/me` sul server e sostituire i dati dimostrativi con contenuti editoriali provenienti dal CMS.

Prima della raccolta reale, il team dovra' definire con il referente privacy finalita', base giuridica, testo e versione dei consensi, tempi di conservazione, gestione delle richieste di cancellazione e separazione tra dati necessari e marketing facoltativo. Gli eventi di utilizzo dovranno essere raccolti solo secondo le scelte privacy applicabili.
