export type Topic = {
  slug: string;
  name: string;
  kicker: string;
  intro: string;
  image: string;
  accent: string;
  featured: string;
  items: { rubric: string; title: string; format: string; time: string }[];
};

export const topics: Topic[] = [
  {slug:'volley',name:'Volley',kicker:'IL GIOCO, SPIEGATO DA VICINO.',intro:'Partite, regole e persone. Per chi vive già il volley e per chi vuole capire da dove iniziare.',image:'/volley.jpg',accent:'#6347c7',featured:'La partita di sabato: protagonisti e cosa osservare',items:[{rubric:'DA DOVE COMINCIO?',title:'Perché il libero indossa una maglia diversa?',format:'SPIEGAZIONE',time:'3 MIN'},{rubric:'DENTRO LA PASSIONE',title:'Come si tiene unita una squadra dopo cinque sconfitte',format:'INTERVISTA',time:'6 MIN'},{rubric:'FUORI CAMPO',title:'La settimana di chi lavora e gioca in Serie B',format:'VIDEO',time:'8 MIN'}]},
  {slug:'basket',name:'Basket',kicker:'LEGGI IL GIOCO. VIVI LA SQUADRA.',intro:'Le regole essenziali, i momenti decisivi e le storie di chi costruisce il gioco dentro e fuori dal campo.',image:'/volley.jpg',accent:'#ee7356',featured:'Cosa cambia per la squadra con il nuovo allenatore',items:[{rubric:'DA DOVE COMINCIO?',title:'Tre regole per seguire una partita senza perdersi',format:'GUIDA',time:'4 MIN'},{rubric:'IL PUNTO CHE CAMBIA TUTTO',title:'L’ultima azione spiegata da chi sa leggerla',format:'ANALISI',time:'5 MIN'},{rubric:'CHIEDILO A CHI LO VIVE',title:'Le domande della community al playmaker',format:'Q&A',time:'7 MIN'}]},
  {slug:'beach',name:'Beach',kicker:'SABBIA, SCELTE, PERSONE.',intro:'Il beach volley oltre l’estate: tecnica, differenze, allenamento e vite costruite intorno alla rete.',image:'/beach.jpg',accent:'#168cb2',featured:'Dal volley al beach: tre differenze che cambiano il gioco',items:[{rubric:'DA DOVE COMINCIO?',title:'La prima partita: cosa serve davvero',format:'GUIDA',time:'4 MIN'},{rubric:'DENTRO LA PASSIONE',title:'Una giornata con chi vive di beach volley',format:'VIDEO',time:'9 MIN'},{rubric:'IL PUNTO CHE CAMBIA TUTTO',title:'La scelta che decide lo scambio',format:'ANALISI',time:'3 MIN'}]},
  {slug:'music',name:'Music',kicker:'ASCOLTA LE STORIE DIETRO IL SUONO.',intro:'Artisti, luoghi, lavoro e scoperte. Contenuti che fanno conoscere una scena, non soltanto una canzone.',image:'/music.jpg',accent:'#8b4dcc',featured:'Cosa succede prima che si accendano le luci del palco',items:[{rubric:'DENTRO LA PASSIONE',title:'Le persone che rendono possibile un concerto',format:'STORIA',time:'7 MIN'},{rubric:'CHIEDILO A CHI LO VIVE',title:'Quale passione avete iniziato da adulti?',format:'COMMUNITY',time:'3 MIN'},{rubric:'LA PROSSIMA PASSIONE',title:'Tre ascolti per entrare in un mondo nuovo',format:'PERCORSO',time:'12 MIN'}]},
  {slug:'night',name:'Night',kicker:'LA CITTÀ DOPO IL TRAMONTO.',intro:'Persone, luoghi e cultura della notte raccontati con contesto, curiosità e attenzione a chi li vive.',image:'/music.jpg',accent:'#30225d',featured:'Chi fa vivere la città mentre gli altri dormono',items:[{rubric:'DENTRO LA PASSIONE',title:'Una notte vista dalla consolle',format:'VIDEO',time:'8 MIN'},{rubric:'FUORI CAMPO',title:'Il lavoro dietro una serata',format:'STORIA',time:'6 MIN'},{rubric:'DA DOVE COMINCIO?',title:'Come scegliere un evento che ti somiglia',format:'GUIDA',time:'4 MIN'}]},
  {slug:'entertainment',name:'Entertainment',kicker:'LE STORIE E CHI LE RENDE POSSIBILI.',intro:'Spettacolo, creatività e protagonisti: format capaci di coinvolgere senza enfasi artificiale.',image:'/music.jpg',accent:'#c34083',featured:'Come nasce un momento che resta al pubblico',items:[{rubric:'DENTRO LA PASSIONE',title:'Dal copione alla scena: il lavoro che non si vede',format:'STORIA',time:'7 MIN'},{rubric:'CHIEDILO A CHI LO VIVE',title:'Le domande della community ai protagonisti',format:'Q&A',time:'5 MIN'},{rubric:'LA PROSSIMA PASSIONE',title:'Un invito a scoprire un linguaggio nuovo',format:'PERCORSO',time:'9 MIN'}]},
];

export const topicBySlug = (slug: string) => topics.find((topic) => topic.slug === slug);
