import {ArrowUpRight} from 'lucide-react';

export function SiteHeader({active}:{active?:string}){
  return <header className="header inner-header"><a href="/" aria-label="LIKENet home"><img className="logo" src="/logo.png" alt="LIKENet — La TV del Futuro"/></a><nav aria-label="Navigazione principale"><a className={active==='esplora'?'active':''} href="/#passioni">Esplora</a><a className={active==='live'?'active':''} href="/#ora">Live <span className="dot"/></a><a className={active==='per-te'?'active':''} href="/#per-te">Per te</a></nav><a className="me" href="/me"><span>ME</span><b>Il tuo LIKENet</b><ArrowUpRight size={16}/></a></header>
}

export function SiteFooter(){return <footer className="wrap"><img src="/logo.png" alt="LIKENet"/><p>Le tue passioni. Tutte in un posto.</p><span>Demo funzionale per il team IT<br/>© 2026 LIKENet</span></footer>}
