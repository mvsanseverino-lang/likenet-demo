'use client';

import {useEffect} from 'react';

const EVENTS_KEY='likenet-demo-events';
const SESSION_KEY='likenet-demo-session';

function createSessionId(){
  return typeof crypto!=='undefined'&&'randomUUID' in crypto?crypto.randomUUID():`demo-${Date.now()}`;
}

export function DemoTracker(){
  useEffect(()=>{
    try{
      const sessionId=localStorage.getItem(SESSION_KEY)||createSessionId();
      localStorage.setItem(SESSION_KEY,sessionId);
      const events=JSON.parse(localStorage.getItem(EVENTS_KEY)||'[]');
      events.push({name:'page_view',data:{path:window.location.pathname},sessionId,at:new Date().toISOString()});
      localStorage.setItem(EVENTS_KEY,JSON.stringify(events.slice(-50)));
    }catch{}
  },[]);

  return null;
}
