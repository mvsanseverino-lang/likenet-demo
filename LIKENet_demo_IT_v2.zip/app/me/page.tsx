'use client';

import {useEffect,useState} from 'react';
import {ArrowRight,Bookmark,Clock,Compass,Play,Settings,Sparkles,Trash2} from 'lucide-react';
import {SiteHeader} from '@/components/site-shell';

type DemoProfile={name:string;email:string;city?:string;age:string;interests:string[];consent:{profile:boolean;marketing:boolean;version:string;acceptedAt:string};createdAt:string};

export default function MePage(){
  const [profile,setProfile]=useState<DemoProfile|null>(null);
  const [eventCount,setEventCount]=useState(0);

  useEffect(()=>{
    try{
      const saved=localStorage.getItem('likenet-demo-profile');
      if(saved)setProfile(JSON.parse(saved));
      const events=JSON.parse(localStorage.getItem('likenet-demo-events')||'[]');
      setEventCount(events.length);
    }catch{}
  },[]);

  const clearDemo=()=>{
    localStorage.removeItem('likenet-demo-profile');
    localStorage.removeItem('likenet-demo-events');
    localStorage.removeItem('likenet-demo-session');
    setProfile(null);
    setEventCount(0);
  };

  const firstName=profile?.name?.split(' ')[0]||'Marco';
  const interests=profile?.interests?.length?profile.interests:['Volley','Music','Beach'];

  return <><SiteHeader active="per-te"/><main className="member-page"><div className="wrap"><div className="member-top"><div><span className="demo-pill">ANTEPRIMA AREA RISERVATA</span><h1>Ciao, {firstName}.<br/><span>Cosa ti va oggi?</span></h1></div><a href="/iscriviti"><Settings size={17}/> Gestisci profilo</a></div>{profile&&<section className="demo-profile-strip"><div><span>PROFILO DEMO · SALVATO SOLO SU QUESTO DISPOSITIVO</span><b>{profile.email}</b><p>{interests.join(' · ')} · {profile.age}{profile.city?` · ${profile.city}`:''} · {eventCount} eventi demo</p></div><button onClick={clearDemo}><Trash2/> Cancella i dati demo</button></section>}<div className="member-layout"><aside className="member-sidebar"><a className="selected" href="/me"><Sparkles/>Per te</a><a href="/me/preferiti"><Bookmark/>Preferiti</a><a href="/me/percorsi"><Compass/>I tuoi percorsi</a><div><span>LE TUE PASSIONI</span>{interests.map(interest=><a key={interest} href={`/passioni/${interest.toLowerCase()}`}>● {interest}</a>)}</div></aside><div className="member-main"><section className="continue-card"><img src="/volley.jpg" alt="Partita di pallavolo"/><div><span className="topic-kicker">CONTINUA DA DOVE ERI RIMASTO</span><h2>Come si tiene unita una squadra dopo cinque sconfitte</h2><p>Hai visto 3 minuti su 8.</p><div className="watch-progress"><span/></div><button><Play size={17} fill="currentColor"/> Continua</button></div></section><section><div className="section-head"><h2>Il tuo percorso della settimana</h2><span className="small-label">VOLLEY · 3 TAPPE</span></div><div className="path-grid"><a href="/passioni/volley"><span>01</span><b>Capisci la regola</b><small><Clock/>3 MIN</small></a><a href="/passioni/volley"><span>02</span><b>Conosci i protagonisti</b><small><Clock/>6 MIN</small></a><a href="/passioni/beach"><span>03</span><b>Scopri il beach</b><small><Clock/>5 MIN</small></a></div></section><section className="member-saved"><div className="section-head"><h2>Salvati per dopo</h2><a href="/me/preferiti">Vedi tutti <ArrowRight/></a></div><div><img src="/music.jpg" alt="Concerto"/><span><b>Le persone che rendono possibile un concerto</b><small>DENTRO LA PASSIONE · 7 MIN</small></span><Bookmark fill="currentColor"/></div><div><img src="/beach.jpg" alt="Beach volley"/><span><b>Dal volley al beach: tre differenze che cambiano il gioco</b><small>LA PROSSIMA PASSIONE · 5 MIN</small></span><Bookmark fill="currentColor"/></div></section></div></div></div></main></>;
}
