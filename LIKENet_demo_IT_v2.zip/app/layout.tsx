import type { Metadata } from 'next';
import { Geist, Geist_Mono } from 'next/font/google';
import {DemoTracker} from '@/components/demo-tracker';
import './globals.css';

const geistSans = Geist({
  variable: '--font-geist-sans',
  subsets: ['latin'],
});

const geistMono = Geist_Mono({
  variable: '--font-geist-mono',
  subsets: ['latin'],
});

export const metadata: Metadata = {
  title: 'LIKENet — Le tue passioni. Tutte in un posto.',
  icons: { icon: '/favicon.png' },
  description: 'Storie, spiegazioni, dirette e protagonisti: la proposta editoriale LIKENet Passions + ME.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="it">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        <DemoTracker />
        {children}
      </body>
    </html>
  );
}
