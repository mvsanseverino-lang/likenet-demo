import {notFound} from 'next/navigation';
import {ArrowLeft,ArrowRight,ArrowUpRight,Bookmark,Clock,Play} from 'lucide-react';
import {SiteFooter,SiteHeader} from '@/components/site-shell';
import {topicBySlug,topics} from '@/lib/editorial';

export function generateStaticParams(){return topics.map(({slug})=>({slug}));}

export default async function TopicPage({params}:{params:Promise<{slug:string}>}){
  const {slug}=await params; const topic=topicBySlug(slug); if(!topic) notFound();
  return <><SiteHeader active="esplora"/><main className="topic-page" style={{'--topic-accent':topic.accent} as React.CSSProperties}>
    <section className="topic-hero"><img src={topic.image} alt=""/><div className="topic-shade"/><div className="wrap topic-hero-content"><a className="back-link" href="/#passioni"><ArrowLeft size={17}/> Tutte le passioni</a><div><span className="topic-kicker">{topic.kicker}</span><h1>{topic.name}</h1><p>{topic.intro}</p></div><a className="follow-topic" href="/iscriviti"><Bookmark size={18}/> Segui {topic.name}</a></div></section>
    <section className="wrap topic-live"><div className="section-head"><h2><span className="live-dot"/>Ora in {topic.name}</h2><span className="small-label">IDEA EDITORIALE</span></div><button className="topic-feature"><div><span className="live-badge">● LIVE</span><span className="topic-kicker">FAR VIVERE</span></div><h2>{topic.featured}</h2><span className="topic-play"><Play size={18} fill="currentColor"/> Guarda la presentazione</span><ArrowUpRight className="corner-arrow"/></button></section>
    <section className="wrap topic-content"><div className="section-head"><h2>Storie, risposte, protagonisti.</h2><span className="small-label">CONTENUTI PUBBLICI</span></div><div className="topic-grid">{topic.items.map((item,i)=><article className="topic-card" key={item.title}><div className="topic-card-number">0{i+1}</div><span className="topic-kicker">{item.rubric}</span><h3>{item.title}</h3><div className="topic-card-meta"><span>{item.format}</span><span><Clock size={14}/>{item.time}</span></div><button aria-label={`Apri ${item.title}`}><ArrowUpRight/></button></article>)}</div></section>
    <section className="wrap join-banner"><div><span className="topic-kicker">IL TUO LIKENET</span><h2>Salva ciò che ti interessa.<br/>Riprendi da dove eri rimasto.</h2><p>L’iscrizione è gratuita. Nella demo non viene creato alcun account.</p></div><a href="/iscriviti">Scopri l’area iscritti <ArrowRight size={18}/></a></section>
  </main><SiteFooter/></>;
}
